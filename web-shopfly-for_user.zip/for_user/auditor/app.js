'use strict';

const crypto = require('crypto');
const dns = require('dns').promises;
const { execFileSync } = require('child_process');
const http = require('http');
const puppeteer = require('puppeteer');

const host = process.env.HOST || 'shopfly.test';
const maxBrowsers = Number(process.env.MAX_BROWSERS || 32);
const holdMs = Number(process.env.BROWSER_HOLD_MS || 240000);
let active = 0;
let dnsReady = false;
let browserReady = false;
let sharedBrowser = null;
let browserLaunch = null;
const contexts = new Set();
const usedTickets = new Map();
const auditKey = Buffer.from(process.env.AUDIT_HMAC_KEY || '', 'utf8');
const reviewsLockUrl = process.env.REVIEWS_LOCK_URL || '';
const lanePattern = /^q[0-3][0-9a-f]$/;

if (auditKey.length < 32) throw new Error('AUDIT_HMAC_KEY must contain at least 32 bytes');
if (!/^http:\/\/172\.28\.\d{1,3}\.10$/.test(reviewsLockUrl)) throw new Error('REVIEWS_LOCK_URL must target the isolated Reviews service');

const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

async function dnsSelfTest() {
  const official = await dns.resolve4(`reviews.${host}`);
  const alias = await dns.resolve4(process.env.DNS_SELFTEST_NAME || `shopfly-auditor-1.${host}`);
  if (!official.length || !alias.length) throw new Error('empty DNS self-test answer');
  dnsReady = true;
  console.log(`startup DNS self-test ok official=${official[0]} docker_alias=${alias[0]}`);
}

function verifyTicket(ticket) {
  if (!/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(ticket || '')) return null;
  const [payload, signature] = ticket.split('.');
  const expected = crypto.createHmac('sha256', auditKey).update(payload).digest();
  let supplied;
  try { supplied = Buffer.from(signature, 'base64url'); } catch { return null; }
  if (supplied.length !== expected.length || !crypto.timingSafeEqual(supplied, expected)) return null;
  try {
    const claims = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    const now = Math.floor(Date.now() / 1000);
    if (claims.v !== 1 || !lanePattern.test(claims.lane || '') ||
        !/^[A-Za-z0-9_{}-]{3,100}$/.test(claims.seller || '') ||
        !/^[0-9a-f]{24}$/.test(claims.nonce || '') || !Number.isInteger(claims.exp) ||
        claims.exp < now || claims.exp > now + 900) return null;
    return claims;
  } catch { return null; }
}

function consumeTicket(ticket, claims) {
  const now = Math.floor(Date.now() / 1000);
  for (const [value, expiry] of usedTickets) if (expiry < now) usedTickets.delete(value);
  if (usedTickets.has(ticket)) return false;
  if (usedTickets.size >= 4096) usedTickets.delete(usedTickets.keys().next().value);
  usedTickets.set(ticket, claims.exp);
  return true;
}

async function ensureBrowser() {
  if (sharedBrowser && sharedBrowser.connected) return sharedBrowser;
  if (!browserLaunch) {
    browserLaunch = puppeteer.launch({
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--ignore-certificate-errors',
        '--disable-dev-shm-usage',
      ],
    }).then(browser => {
      sharedBrowser = browser;
      browserReady = true;
      browser.on('disconnected', () => {
        if (sharedBrowser === browser) {
          sharedBrowser = null;
          browserReady = false;
        }
      });
      console.log('auditor shared Chromium ready');
      return browser;
    }).finally(() => {
      browserLaunch = null;
    });
  }
  return browserLaunch;
}

async function lockReviews(ticket) {
  let lastError = new Error('Reviews audit lock unavailable');
  for (let attempt = 1; attempt <= 4; attempt += 1) {
    try {
      const locked = await fetch(`${reviewsLockUrl}/internal/audit-lock/${ticket}`, {
        method: 'POST', signal: AbortSignal.timeout(10000),
      });
      if (locked.status === 204) return;
      lastError = new Error(`lock status ${locked.status}`);
    } catch (error) {
      lastError = error;
    }
    if (attempt < 4) await wait(150);
  }
  throw lastError;
}

async function audit(seller, lane) {
  let context;
  const launchId = `${Date.now().toString(36)}-${active}`;
  console.log(`auditor launch id=${launchId} lane=${lane} active=${active}`);
  try {
    const browser = await ensureBrowser();
    context = await browser.createBrowserContext();
    contexts.add(context);
    const page = await context.newPage();
    page.setDefaultNavigationTimeout(20000);
    let signalExfiltration;
    const exfiltrationStarted = new Promise(resolve => { signalExfiltration = resolve; });
    page.on('request', request => {
      try {
        const url = new URL(request.url());
        if (url.hostname === `reviews-${lane}.${host}` && /%0d/i.test(url.pathname)) {
          signalExfiltration();
        }
      } catch {}
    });
    try {
      await page.goto(`https://reviews-${lane}.${host}/seller/${encodeURIComponent(seller)}`, {
        waitUntil: 'networkidle2', timeout: 20000,
      });
    } catch (error) {
      console.log(`auditor navigation id=${launchId} result=${error.name}`);
    }
    await Promise.race([
      wait(holdMs),
      exfiltrationStarted.then(() => wait(5000)),
    ]);
  } catch (error) {
    console.log(`auditor failure id=${launchId} error=${error.name}`);
  } finally {
    if (context) {
      contexts.delete(context);
      await context.close().catch(() => {});
    }
    active -= 1;
    console.log(`auditor close id=${launchId} active=${active}`);
  }
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'GET' && req.url === '/healthz') {
    res.writeHead(dnsReady && browserReady ? 200 : 503);
    return res.end(dnsReady && browserReady ? 'ok' : 'auditor startup pending');
  }
  if (req.method === 'GET' && req.url === '/') {
    res.writeHead(200);
    return res.end('Shopfly automated seller auditor');
  }
  if (req.method === 'GET' && req.url === '/check-warehouse') {
    try {
      const output = execFileSync('ping', ['-nc', '1', 'warehouse'], { timeout: 10000, encoding: 'utf8' });
      res.writeHead(200);
      return res.end(output);
    } catch (error) {
      res.writeHead(503);
      return res.end(String(error.stdout || 'warehouse check failed'));
    }
  }
  if (req.method === 'GET' && req.url.startsWith('/dispatch-auditor/')) {
    const ticket = req.url.slice('/dispatch-auditor/'.length).split(/[?#]/, 1)[0];
    const claims = verifyTicket(ticket);
    if (!claims) {
      console.log('auditor dispatch rejected reason=invalid-ticket');
      res.writeHead(401);
      return res.end('Invalid audit ticket');
    }
    if (active >= maxBrowsers) {
      console.log(`auditor dispatch rejected reason=capacity lane=${claims.lane} active=${active}`);
      res.writeHead(429);
      return res.end('All Shopfly auditors are busy');
    }
    if (!consumeTicket(ticket, claims)) {
      console.log(`auditor dispatch rejected reason=consumed lane=${claims.lane}`);
      res.writeHead(401);
      return res.end('Consumed audit ticket');
    }
    active += 1;
    try {
      await lockReviews(ticket);
    } catch (error) {
      usedTickets.delete(ticket);
      active -= 1;
      console.log(`auditor dispatch rejected reason=lock-unavailable lane=${claims.lane} error=${error.name}`);
      res.writeHead(503);
      return res.end('Reviews audit lock unavailable');
    }
    res.writeHead(202);
    res.end('Auditor is reviewing Shopfly sellers...');
    audit(claims.seller, claims.lane);
    return;
  }
  res.writeHead(404);
  res.end('Not found');
});

async function shutdown() {
  server.close();
  await Promise.all([...contexts].map(context => context.close().catch(() => {})));
  if (sharedBrowser) await sharedBrowser.close().catch(() => {});
  process.exit(0);
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

async function awaitDns() {
  while (!dnsReady) {
    try {
      await dnsSelfTest();
    } catch (error) {
      console.log(`startup DNS self-test failed error=${error.code || error.name}`);
      await wait(1000);
    }
  }
}
awaitDns();

async function awaitBrowser() {
  while (!browserReady) {
    try {
      await ensureBrowser();
    } catch (error) {
      console.log(`auditor Chromium startup failed error=${error.name}`);
      await wait(1000);
    }
  }
}
awaitBrowser();

server.listen(80, '0.0.0.0', () => console.log(`auditor listening on 80 chrome=126.0.6478.182 puppeteer=22.13.1`));
