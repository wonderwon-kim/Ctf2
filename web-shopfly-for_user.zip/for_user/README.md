# Shopfly

make start 로 도커 올려서 도커에서 딴 뒤에 서버에서 플레그를 회수해주세요.

```sh
make start
```

```sh
make down
```
