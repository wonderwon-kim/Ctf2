#!/usr/bin/env python3
import socket
import struct

query = b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x03bad\x07invalid\x00\x00\x01\x00\x01"
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.settimeout(0.5)
sock.sendto(query, ("127.0.0.1", 53))
reply, _ = sock.recvfrom(512)
if len(reply) < 12 or struct.unpack("!H", reply[:2])[0] != 0x1234:
    raise SystemExit(1)

