'use strict';
document.documentElement.dataset.catalogReady = 'true';
