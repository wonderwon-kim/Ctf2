'use strict';

const crypto = require('crypto');
const { execFileSync } = require('child_process');
const path = require('path');
const express = require('express');

const app = express();
const socketIds = new WeakMap();
let nextSocketId = 1;
const auditKey = Buffer.from(process.env.AUDIT_HMAC_KEY || '', 'utf8');
const publicHost = process.env.PUBLIC_HOST || process.env.HOST || 'shopfly.test';
const publicPort = String(process.env.PUBLIC_PORT || '');
const portSuffix = publicPort && publicPort !== '443' ? `:${publicPort}` : '';
const lanePattern = /^q[0-3][0-9a-f]$/;

if (auditKey.length < 32) throw new Error('AUDIT_HMAC_KEY must contain at least 32 bytes');

const products = [
  {
    id: 'sky-lantern', name: 'Aurora Desk Lantern', price: '$42', tag: 'Bestseller', theme: 'aurora',
    category: 'home', collection: 'quiet-spaces', seller: 'Lumen Fold', sellerHandle: 'lumenfold', rating: '4.9', reviews: 184,
    subtitle: 'A warm, dimmable glow for slower evenings.', stock: 'In stock · ships tomorrow',
    description: 'A compact powder-coated lantern with a soft, glare-free diffuser and three considered brightness levels. Built for desks, bedside tables, and the corner that needs a little warmth.',
    features: ['USB-C rechargeable', '18-hour low-light runtime', 'Recycled aluminum body', 'Two-year seller warranty'],
  },
  {
    id: 'orbit-mug', name: 'Orbit Stoneware Mug', price: '$18', tag: 'Ships today', theme: 'orbit',
    category: 'home', collection: 'morning-rituals', seller: 'Soft Geometry', sellerHandle: 'softgeometry', rating: '4.8', reviews: 92,
    subtitle: 'Hand-finished stoneware with a balanced handle.', stock: 'In stock · ships today',
    description: 'A tactile everyday mug thrown in small batches and finished with a satin mineral glaze. The low center of gravity keeps it steady beside laptops and sketchbooks.',
    features: ['12 oz capacity', 'Dishwasher safe', 'Lead-free mineral glaze', 'Packed without plastic'],
  },
  {
    id: 'field-pack', name: 'Field Notes Travel Pack', price: '$36', tag: 'Carbon neutral', theme: 'field',
    category: 'travel', collection: 'weekend-away', seller: 'North & Pine Goods', sellerHandle: 'northpine', rating: '4.9', reviews: 137,
    subtitle: 'A modular pouch for the things that wander.', stock: 'Low stock · ships in 2 days',
    description: 'A weather-resistant organizer sized for cables, stationery, toiletries, or the small essentials that otherwise disappear at the bottom of a bag.',
    features: ['Recycled ripstop shell', 'Three removable dividers', 'YKK recycled zip', 'Lifetime repair support'],
  },
  {
    id: 'arc-stand', name: 'Arc Book Stand', price: '$31', tag: 'New arrival', theme: 'arc',
    category: 'desk', collection: 'quiet-spaces', seller: 'Lumen Fold', sellerHandle: 'lumenfold', rating: '4.7', reviews: 41,
    subtitle: 'A folded steel rest for books, tablets, and notes.', stock: 'In stock · ships tomorrow',
    description: 'A minimal reading stand with a weighted base and cork contact points. It holds cookbooks, tablets, and reference material at a comfortable viewing angle.',
    features: ['Powder-coated steel', 'Natural cork rests', 'Non-slip base', 'Made in small batches'],
  },
  {
    id: 'linen-catchall', name: 'Linen Bedside Catchall', price: '$24', tag: 'Seller pick', theme: 'linen',
    category: 'home', collection: 'morning-rituals', seller: 'Soft Geometry', sellerHandle: 'softgeometry', rating: '5.0', reviews: 68,
    subtitle: 'Soft structure for the last things you set down.', stock: 'In stock · ships in 2 days',
    description: 'A quilted linen tray that keeps glasses, jewelry, and pocket objects together. Flexible enough to pack flat, structured enough to stay useful.',
    features: ['European flax linen', 'Plant-based batting', 'Machine washable', 'Plastic-free packaging'],
  },
  {
    id: 'signal-bottle', name: 'Signal Water Bottle', price: '$29', tag: 'Road tested', theme: 'signal',
    category: 'travel', collection: 'weekend-away', seller: 'North & Pine Goods', sellerHandle: 'northpine', rating: '4.8', reviews: 116,
    subtitle: 'A slim insulated bottle with a quiet carry loop.', stock: 'In stock · ships today',
    description: 'A double-wall bottle shaped to fit side pockets and crowded bags. The soft-touch loop stays quiet in transit and the wide mouth is easy to clean.',
    features: ['20 oz capacity', '18/8 stainless steel', 'Leak-tested cap', 'Keeps cold for 18 hours'],
  },
];

const collections = [
  { id: 'home', name: 'Home & living', kicker: 'Warm the room', copy: 'Considered pieces for slower mornings and softer evenings.', theme: 'home' },
  { id: 'desk', name: 'Desk & studio', kicker: 'Clear the noise', copy: 'Tools that make space for focused, tactile work.', theme: 'desk' },
  { id: 'travel', name: 'Travel & carry', kicker: 'Go thoughtfully', copy: 'Road-tested essentials with less disposable baggage.', theme: 'travel' },
];

const makers = [
  { handle: 'softgeometry', shop: 'Soft Geometry', maker: 'Maya Chen', place: 'Portland, Oregon', image: 'maya-chen.webp', craft: 'Wheel-thrown ceramics' },
  { handle: 'northpine', shop: 'North & Pine Goods', maker: 'Elias Brooks', place: 'Asheville, North Carolina', image: 'elias-brooks.webp', craft: 'Travel goods & repair' },
  { handle: 'lumenfold', shop: 'Lumen Fold', maker: 'Inés Morales', place: 'Providence, Rhode Island', image: 'ines-morales.webp', craft: 'Lighting & desk objects' },
];

app.use((req, res, next) => {
  if (process.env.CAPTURE_BROWSER_TRANSCRIPT === '1') {
    console.log(`CAPTURE ${JSON.stringify({ method: req.method, url: req.url, version: req.httpVersion, rawHeaders: req.rawHeaders })}`);
  }
  if (!socketIds.has(req.socket)) socketIds.set(req.socket, nextSocketId++);
  res.set('X-Upstream-Connection', `catalog-${socketIds.get(req.socket)}`);
  res.set('Content-Security-Policy', "default-src 'self'; img-src 'self'; style-src 'self'; form-action 'self'; frame-src 'none'; object-src 'none'; base-uri 'none'");
  next();
});
app.use(express.text({ type: '*/*', limit: '256kb' }));
app.use('/static', express.static(path.join(__dirname, 'public'), { fallthrough: false }));

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[character]);
}

function requestLane(req) {
  const hostname = String(req.headers.host || '').split(':', 1)[0].toLowerCase();
  const match = hostname.match(/^catalog-(q[0-3][0-9a-f])(?:\.|$)/);
  return match ? match[1] : 'q00';
}

function marketplaceUrl(req) {
  return `https://reviews-${requestLane(req)}.${publicHost}${portSuffix}`;
}

function page(req, title, body, description = 'Useful objects from independent Shopfly sellers.') {
  const marketplace = marketplaceUrl(req);
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="${escapeHtml(description)}"><title>${escapeHtml(title)}</title><link rel="stylesheet" href="/static/catalog.css"><script defer src="/static/catalog.js"></script></head>
<body><div class="catalog-announcement"><span>Free tracked delivery over $50</span><a href="/shipping">Shipping &amp; returns</a></div>
<header class="catalog-header"><a class="catalog-brand" href="/"><b>S</b><span>Shopfly<small>catalog</small></span></a><nav><a href="/">New arrivals</a><a href="/collections">Collections</a><a href="/collections/home">Home</a><a href="/collections/desk">Desk</a><a href="/collections/travel">Travel</a></nav><div class="header-actions"><form action="/search" method="get"><label><span>Search</span><input name="q" placeholder="Search useful things"><button aria-label="Search">⌕</button></label></form><a href="${marketplace}">Marketplace</a><a class="bag-link" href="/cart">Bag <span>0</span></a></div></header>
<main>${body}</main>
<footer class="catalog-footer"><div class="catalog-footer-grid"><div><a class="catalog-brand footer-logo" href="/"><b>S</b><span>Shopfly<small>catalog</small></span></a><p>Useful objects from independent sellers, selected for everyday life.</p></div><div><h3>Browse</h3><a href="/collections">All collections</a><a href="/search">Search</a><a href="/">New arrivals</a></div><div><h3>About</h3><a href="/about">Our point of view</a><a href="${marketplace}/about#sellers">Seller standards</a><a href="${marketplace}#reviews">Verified reviews</a></div><div><h3>Help</h3><a href="${marketplace}/track">Track an order</a><a href="/shipping">Shipping &amp; returns</a><a href="${marketplace}/about#protection">Buyer protection</a></div></div><div class="catalog-footer-bottom"><span>© 2026 Shopfly Catalog</span><span>Independent sellers · Monitored fulfillment</span></div></footer>
</body></html>`;
}

function productCard(product) {
  return `<a class="product-card" href="/products/${product.id}"><div class="product-art product-photo product-photo-${product.id}"><span class="heart" aria-hidden="true">♡</span></div><div class="product-card-copy"><span class="product-seller">${escapeHtml(product.seller)}</span><span class="tag">${escapeHtml(product.tag)}</span><h3>${escapeHtml(product.name)}</h3><p>${escapeHtml(product.subtitle)}</p><div><strong>${escapeHtml(product.price)}</strong><span>★ ${escapeHtml(product.rating)} <small>(${product.reviews})</small></span></div></div></a>`;
}

function productGrid(items) {
  return `<div class="product-grid">${items.map(productCard).join('')}</div>`;
}

function verifyTicket(ticket) {
  if (!/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(ticket || '')) return null;
  const [payload, signature] = ticket.split('.');
  const expected = crypto.createHmac('sha256', auditKey).update(payload).digest();
  let supplied;
  try { supplied = Buffer.from(signature, 'base64url'); } catch { return null; }
  if (supplied.length !== expected.length || !crypto.timingSafeEqual(supplied, expected)) return null;
  try {
    const claims = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    const now = Math.floor(Date.now() / 1000);
    if (claims.v !== 1 || !lanePattern.test(claims.lane || '') ||
        !/^[A-Za-z0-9_{}-]{3,100}$/.test(claims.seller || '') ||
        !/^[0-9a-f]{24}$/.test(claims.nonce || '') || !Number.isInteger(claims.exp) ||
        claims.exp < now || claims.exp > now + 900) return null;
    return claims;
  } catch { return null; }
}

function auditProof(ticket) {
  return crypto.createHmac('sha256', auditKey).update(`origin-proof:${ticket}`).digest('base64url');
}

function initializeAuditOrigin(req, res) {
  const ticket = String(req.params.ticket || '');
  const claims = verifyTicket(ticket);
  if (!claims || claims.lane !== requestLane(req)) return null;
  res.set('Cache-Control', 'no-store');
  res.set('Set-Cookie', `shopfly_audit=${auditProof(ticket)}; Path=/; Max-Age=600; HttpOnly; Secure; SameSite=Strict`);
  return claims;
}

app.get('/healthz', (_req, res) => res.type('text/plain').send('ok'));
app.get('/audit/bootstrap/:ticket', (req, res) => {
  const claims = initializeAuditOrigin(req, res);
  if (!claims) return res.status(403).type('text/plain').send('Invalid audit ticket');
  res.type('text/plain').send(`Audit origin initialized for ${claims.seller}`);
});
app.post('/audit/bootstrap/:ticket', (req, res) => {
  if (!initializeAuditOrigin(req, res)) return res.status(403).type('text/plain').send('Invalid audit ticket');
  res.send(req.body);
});

app.get('/', (req, res) => {
  const marketplace = marketplaceUrl(req);
  res.send(page(req, 'Shopfly Catalog · Useful by design', `
    <section class="catalog-hero"><div class="catalog-hero-copy"><p class="overline">Edition 06 · Everyday rituals</p><h1>Useful objects,<br><em>chosen with care.</em></h1><p>Independent design for the desk, the doorway, and everywhere in between.</p><div class="hero-links"><a class="catalog-button" href="/collections">Shop the collection →</a><a href="/about">Why Shopfly?</a></div><div class="hero-notes"><span><b>105</b> curated objects</span><span><b>38</b> independent sellers</span><span><b>4.9</b> average rating</span></div></div><a class="featured-object" href="/collections"><div class="feature-art feature-photo"><img src="/static/images/collection-flatlay.webp" alt="Six useful objects from independent Shopfly makers"><span class="feature-caption"><small>Edition 06</small><strong>Everyday rituals</strong><b>6 objects</b></span></div></a></section>
    <section class="service-strip"><span><i>✓</i><b>Seller verified</b><small>Every storefront checked</small></span><span><i>↗</i><b>Tracked delivery</b><small>Fulfillment monitored</small></span><span><i>30</i><b>Buyer protection</b><small>Coverage on every order</small></span><span><i>♻</i><b>Lower-impact packing</b><small>No unnecessary plastic</small></span></section>
    <section class="catalog-section"><div class="catalog-section-heading"><div><p class="overline">Browse by room and rhythm</p><h2>Start with where it lives.</h2></div><a href="/collections">All collections →</a></div><div class="collection-grid">${collections.map(collection => `<a class="collection-card ${collection.theme}" href="/collections/${collection.id}"><div class="collection-visual"><i></i></div><span>${collection.kicker}</span><h3>${collection.name}</h3><p>${collection.copy}</p><b>Explore →</b></a>`).join('')}</div></section>
    <section class="catalog-section arrivals"><div class="catalog-section-heading"><div><p class="overline">Fresh from small studios</p><h2>New &amp; noteworthy.</h2></div><a href="/collections">See everything →</a></div>${productGrid(products.slice(0, 4))}</section>
    <section class="catalog-makers"><div class="catalog-section-heading"><div><p class="overline">Made by people, not inventory feeds</p><h2>Three studios in this edit.</h2></div><a href="${marketplace}#makers">Meet every seller →</a></div><div class="catalog-maker-grid">${makers.map(maker => `<a href="${marketplace}/seller/${maker.handle}"><img src="/static/images/${maker.image}" alt="${escapeHtml(maker.maker)} in the ${escapeHtml(maker.shop)} studio" loading="lazy"><span><small>${escapeHtml(maker.craft)}</small><strong>${escapeHtml(maker.shop)}</strong><em>${escapeHtml(maker.maker)} · ${escapeHtml(maker.place)}</em></span></a>`).join('')}</div></section>
    <section class="editorial"><div class="editorial-art editorial-photo"><img src="/static/images/ines-morales.webp" alt="Inés Morales making a small Lumen Fold lamp" loading="lazy"></div><div><p class="overline light">Meet the seller · Lumen Fold</p><h2>“Warm light should make a small room feel generous.”</h2><p>Inés Morales prototypes every lamp in paper before translating the form into repairable materials.</p><a class="light-link" href="${marketplace}/seller/lumenfold">Visit the storefront →</a></div></section>
    <section class="catalog-section compact-section"><div class="catalog-section-heading"><div><p class="overline">Road tested</p><h2>Ready to leave the house.</h2></div><a href="/collections/travel">Shop travel →</a></div>${productGrid(products.filter(product => product.category === 'travel'))}</section>
  `));
});

app.get('/collections', (req, res) => {
  res.send(page(req, 'Collections · Shopfly Catalog', `<section class="subpage-hero"><p class="overline">Shopfly collections</p><h1>Objects grouped<br>by how life happens.</h1><p>Explore compact edits for home, focused work, and getting out the door.</p></section><section class="catalog-section collection-index"><div class="collection-grid">${collections.map(collection => `<a class="collection-card ${collection.theme}" href="/collections/${collection.id}"><div class="collection-visual"><i></i></div><span>${collection.kicker}</span><h3>${collection.name}</h3><p>${collection.copy}</p><b>${products.filter(product => product.category === collection.id).length} objects →</b></a>`).join('')}</div></section><section class="catalog-section compact-section"><div class="catalog-section-heading"><div><p class="overline">Everything, together</p><h2>All useful objects.</h2></div><span>${products.length} products</span></div>${productGrid(products)}</section>`));
});

app.get('/collections/:id', (req, res) => {
  const collection = collections.find(item => item.id === req.params.id);
  if (!collection) return res.status(404).send(page(req, 'Collection not found · Shopfly', '<section class="empty-page"><span>404</span><h1>That collection wandered off.</h1><p>Try the complete catalog instead.</p><a class="catalog-button" href="/collections">Browse collections</a></section>'));
  const items = products.filter(product => product.category === collection.id);
  res.send(page(req, `${collection.name} · Shopfly Catalog`, `<section class="collection-hero ${collection.theme}"><div><p class="overline">${escapeHtml(collection.kicker)}</p><h1>${escapeHtml(collection.name)}</h1><p>${escapeHtml(collection.copy)}</p><span>${items.length} objects · Verified independent sellers</span></div><div class="collection-hero-art"><i></i></div></section><section class="catalog-section compact-section"><div class="filter-row"><span>Showing all ${items.length} objects</span><div><button type="button">Featured</button><button type="button">Newest</button><button type="button">Price</button></div></div>${productGrid(items)}</section>`));
});

app.get('/search', (req, res) => {
  const query = String(req.query.q || '').trim();
  const lowered = query.toLowerCase();
  const matches = query ? products.filter(product => [product.name, product.subtitle, product.category, product.seller].join(' ').toLowerCase().includes(lowered)) : products;
  const heading = query ? `Results for “${escapeHtml(query)}”` : 'Search the catalog';
  res.send(page(req, `${query ? `${query} · ` : ''}Search · Shopfly`, `<section class="search-page"><p class="overline">Find something useful</p><h1>${heading}</h1><form action="/search" method="get"><input name="q" value="${escapeHtml(query)}" placeholder="Try “mug”, “travel”, or a seller name"><button>Search</button></form><p>${matches.length} ${matches.length === 1 ? 'object' : 'objects'} found</p></section><section class="catalog-section compact-section">${matches.length ? productGrid(matches) : '<div class="empty-results"><span>⌕</span><h2>No objects matched that search.</h2><p>Try a material, room, or broader term.</p><a href="/collections">Browse all collections →</a></div>'}</section>`));
});

app.get('/products/:id', (req, res) => {
  const product = products.find(item => item.id === req.params.id);
  if (!product) return res.status(404).type('text/plain').send('Product not found');
  const marketplace = marketplaceUrl(req);
  const related = products.filter(item => item.id !== product.id && (item.category === product.category || item.collection === product.collection)).slice(0, 3);
  res.send(page(req, `${product.name} · Shopfly`, `<nav class="breadcrumb"><a href="/">Catalog</a><span>›</span><a href="/collections/${product.category}">${escapeHtml(product.category)}</a><span>›</span><b>${escapeHtml(product.name)}</b></nav><section class="product-detail"><div class="detail-gallery"><div class="detail-art product-photo product-photo-${product.id}"><span class="gallery-note">Made in small batches by ${escapeHtml(product.seller)}</span></div><div class="thumbnail-row"><button class="active" aria-label="Front view"></button><button aria-label="Detail view"></button><button aria-label="Scale view"></button></div></div><div class="detail-copy"><div class="detail-heading"><span class="tag">${escapeHtml(product.tag)}</span><button class="detail-heart" type="button">♡ Save</button></div><h1>${escapeHtml(product.name)}</h1><p class="product-subtitle">${escapeHtml(product.subtitle)}</p><div class="detail-rating"><span>★★★★★</span><a href="${marketplace}#reviews">${product.rating} · ${product.reviews} verified reviews</a></div><strong class="detail-price">${escapeHtml(product.price)}</strong><p class="product-description">${escapeHtml(product.description)}</p><ul class="feature-list">${product.features.map(feature => `<li>${escapeHtml(feature)}</li>`).join('')}</ul><a class="buy-button" href="/cart?add=${product.id}">Add to basket <span>${escapeHtml(product.price)}</span></a><div class="fulfillment-card"><span class="fulfillment-icon">↗</span><div><strong>${escapeHtml(product.stock)}</strong><p>Tracked Shopfly fulfillment from <a href="${marketplace}/seller/${product.sellerHandle}">${escapeHtml(product.seller)}</a></p></div></div><details><summary>Materials &amp; care</summary><p>Care details and material origin are verified by the seller and included with your order.</p></details><details><summary>Delivery &amp; returns</summary><p>Tracked delivery is included. Eligible objects can be returned within 30 days.</p></details></div></section><section class="catalog-section related"><div class="catalog-section-heading"><div><p class="overline">Keep exploring</p><h2>Objects that sit well together.</h2></div></div>${productGrid(related)}</section>`));
});

app.get('/cart', (req, res) => {
  const product = products.find(item => item.id === req.query.add);
  const contents = product ? `<div class="cart-item"><div class="cart-thumb product-photo product-photo-${product.id}"></div><div><span>${escapeHtml(product.seller)}</span><h2>${escapeHtml(product.name)}</h2><p>${escapeHtml(product.stock)}</p><a href="/cart">Remove</a></div><strong>${escapeHtml(product.price)}</strong></div>` : '<div class="empty-bag"><span>◡</span><h2>Your bag has room.</h2><p>Fill it with something useful from an independent seller.</p><a class="catalog-button" href="/collections">Explore the catalog</a></div>';
  res.send(page(req, 'Your bag · Shopfly Catalog', `<section class="cart-page"><div><p class="overline">Shopfly checkout</p><h1>Your bag</h1>${contents}</div><aside><h2>Order summary</h2><dl><div><dt>Objects</dt><dd>${product ? product.price : '$0'}</dd></div><div><dt>Tracked delivery</dt><dd>${product ? '$6' : '$0'}</dd></div><div><dt>Buyer protection</dt><dd>Included</dd></div></dl><div class="cart-total"><span>Total</span><strong>${product ? '$' + (Number(product.price.slice(1)) + 6) : '$0'}</strong></div><button ${product ? '' : 'disabled'}>Continue to checkout</button><p>Secure checkout · 30-day buyer protection</p></aside></section>`));
});

app.get('/about', (req, res) => {
  const marketplace = marketplaceUrl(req);
  res.send(page(req, 'Our point of view · Shopfly Catalog', `<section class="subpage-hero"><p class="overline">Our point of view</p><h1>Less endless choice.<br>More lasting usefulness.</h1><p>The Shopfly catalog is edited, not filled. We look for independent design, honest materials, and objects that make daily routines feel considered.</p></section><section class="manifesto"><article><span>01</span><h2>Useful earns its place.</h2><p>We choose objects with a clear purpose, then look for proportion, repairability, and the small details that make repeated use satisfying.</p></article><article><span>02</span><h2>Independent stays visible.</h2><p>Seller names, fulfillment records, and verified feedback remain part of the product—not hidden behind a marketplace label.</p></article><article><span>03</span><h2>Fewer, better signals.</h2><p>No sponsored ranking. No artificial countdowns. Just compact collections and the context needed to choose well.</p></article></section><section class="editorial about-editorial"><div class="editorial-art"><span></span><i></i></div><div><p class="overline light">Behind every object</p><h2>Designed, packed, and supported by real people.</h2><p>Shopfly’s marketplace layer verifies storefronts and monitors fulfillment while sellers keep their own voice.</p><a class="light-link" href="${marketplace}/about">How the marketplace works →</a></div></section>`));
});

app.get('/shipping', (req, res) => {
  const marketplace = marketplaceUrl(req);
  res.send(page(req, 'Shipping & returns · Shopfly', `<section class="subpage-hero small-hero"><p class="overline">Delivery without guesswork</p><h1>From their studio<br>to your door.</h1><p>Every physical Shopfly order uses tracked delivery and remains covered by marketplace monitoring.</p></section><section class="shipping-grid"><article><span>01</span><h2>Handling</h2><p>Each product page shows the seller’s current dispatch estimate. Most in-stock objects leave within two business days.</p></article><article><span>02</span><h2>Tracking</h2><p>A tracking number appears after carrier handoff. Shopfly monitors exceptions and keeps delivery status visible.</p></article><article><span>03</span><h2>Returns</h2><p>Eligible unused goods can be returned within 30 days. Custom and made-to-order objects show separate terms.</p></article><article><span>04</span><h2>Protection</h2><p>Missing or materially misrepresented orders can be reviewed through Shopfly buyer protection.</p></article></section><section class="shipping-cta"><div><p class="overline">Already ordered?</p><h2>See the latest checkpoint.</h2></div><a class="catalog-button" href="${marketplace}/track">Track your order →</a></section>`));
});

app.get('/healthcheck', (_req, res) => {
  try {
    const output = execFileSync('ping', ['-nc', '1', 'catalog'], { timeout: 10000, encoding: 'utf8' });
    // Keep the leading response in flight long enough for a second public
    // request to select another lane-local upstream connection. The hold is
    // asynchronous, so concurrent lanes do not block Catalog's event loop.
    setTimeout(() => res.type('text/plain').send(output), 250);
  } catch (error) {
    res.status(503).type('text/plain').send(String(error.stdout || 'catalog healthcheck failed'));
  }
});

app.post('/healthcheck', (req, res) => res.send(req.body));
app.use((_req, res) => res.status(404).type('text/plain').send('Catalog item not found'));

const server = app.listen(80, '0.0.0.0', () => console.log('catalog listening on 80'));
if (process.env.CAPTURE_BROWSER_TRANSCRIPT === '1') {
  let rawConnection = 0;
  server.on('connection', socket => {
    const id = ++rawConnection;
    socket.on('data', chunk => console.log(`RAW connection=${id} hex=${chunk.toString('hex')}`));
  });
}
