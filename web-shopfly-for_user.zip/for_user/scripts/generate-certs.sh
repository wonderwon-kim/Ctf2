#!/bin/sh
set -eu

project_root=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
cd "$project_root"
env_file=${SHOPFLY_ENV_FILE:-$project_root/.env}
runtime_dir=${SHOPFLY_RUNTIME_DIR:-$project_root/.runtime}
mkdir -p "$runtime_dir/certs"

host=$(sed -n 's/^HOST=//p' "$env_file")
public_host=$(sed -n 's/^PUBLIC_HOST=//p' "$env_file")
if [ -z "$public_host" ]; then public_host="$host"; fi

if [ ! -s "$runtime_dir/certs/gateway.key" ] || [ ! -s "$runtime_dir/certs/gateway.crt" ]; then
    openssl req -x509 -newkey rsa:2048 -sha256 -nodes -days 7 \
      -subj "/CN=*.$host" \
      -addext "subjectAltName=DNS:$host,DNS:*.$host,DNS:$public_host,DNS:*.$public_host" \
      -keyout "$runtime_dir/certs/gateway.key" \
      -out "$runtime_dir/certs/gateway.crt" >/dev/null 2>&1
fi

if [ ! -s "$runtime_dir/certs/warehouse.key" ] || [ ! -s "$runtime_dir/certs/warehouse.crt" ]; then
    openssl req -x509 -newkey rsa:2048 -sha256 -nodes -days 7 \
      -subj "/CN=warehouse" \
      -addext "subjectAltName=DNS:warehouse" \
      -keyout "$runtime_dir/certs/warehouse.key" \
      -out "$runtime_dir/certs/warehouse.crt" >/dev/null 2>&1
fi

chmod 600 "$runtime_dir"/certs/*.key
echo "Ephemeral development certificates are ready in $runtime_dir/certs"
