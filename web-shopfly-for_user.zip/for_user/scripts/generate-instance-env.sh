#!/bin/sh
set -eu

project_root=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
cd "$project_root"
env_file=${SHOPFLY_ENV_FILE:-$project_root/.env}
runtime_dir=${SHOPFLY_RUNTIME_DIR:-$project_root/.runtime}
mkdir -p "$(dirname "$env_file")" "$runtime_dir"

if [ ! -f "$env_file" ]; then
    instance_name="${INSTANCE_NAME:-shopfly}"
    case "$instance_name" in
      ''|*[!a-z0-9_-]*|[_-]*)
        echo "INSTANCE_NAME must start with a lowercase letter or digit and contain only a-z, 0-9, _ or -" >&2
        exit 1
        ;;
    esac
    instance_octet="${INSTANCE_OCTET:-$((20 + ($(od -An -N1 -tu1 /dev/urandom) % 180)))}"
    backoffice_octet=$((instance_octet + 1))
    if [ "$backoffice_octet" -gt 250 ]; then backoffice_octet=19; fi
    host="${SHOPFLY_HOST:-shopfly.test}"
    public_host="${SHOPFLY_PUBLIC_HOST:-$host}"
    host_regex=$(printf '%s' "$host" | sed 's/\./\\\\./g')
    public_host_regex=$(printf '%s' "$public_host" | sed 's/\./\\\\./g')
    public_port=${PUBLIC_PORT:-8443}
    if [ "$public_port" = 443 ]; then
        public_authority=$public_host
    else
        public_authority=$public_host:$public_port
    fi
    audit_hmac_key="${AUDIT_HMAC_KEY:-$(od -An -N32 -tx1 /dev/urandom | tr -d ' \n')}"
    cat > "$env_file" <<EOF
COMPOSE_PROJECT_NAME=$instance_name
INSTANCE_NAME=$instance_name
RUNTIME_DIR=$runtime_dir
HOST=$host
PUBLIC_HOST=$public_host
HOST_REGEX=$host_regex
PUBLIC_HOST_REGEX=$public_host_regex
PUBLIC_AUTHORITY=$public_authority
REBIND_ZONE=r.$host
SHOPNET=172.28.$instance_octet
BACKOFFICE=172.29.$backoffice_octet
PUBLIC_PORT=$public_port
REBIND_AFTER_SECONDS=${REBIND_AFTER_SECONDS:-55}
REBIND_RESET_SECONDS=${REBIND_RESET_SECONDS:-180}
BROWSER_HOLD_MS=${BROWSER_HOLD_MS:-240000}
MAX_BROWSERS=${MAX_BROWSERS:-32}
AUDIT_HMAC_KEY=$audit_hmac_key
AUDIT_TICKET_TTL_SECONDS=${AUDIT_TICKET_TTL_SECONDS:-600}
AUDIT_WRITE_LOCK_SECONDS=${AUDIT_WRITE_LOCK_SECONDS:-180}
EOF
fi

host=$(sed -n 's/^HOST=//p' "$env_file")
public_host=$(sed -n 's/^PUBLIC_HOST=//p' "$env_file")
public_port=$(sed -n 's/^PUBLIC_PORT=//p' "$env_file")
shopnet=$(sed -n 's/^SHOPNET=//p' "$env_file")
rebind_zone=$(sed -n 's/^REBIND_ZONE=//p' "$env_file")
host_regex=$(printf '%s' "$host" | sed 's/\./\\./g')
public_host_regex=$(printf '%s' "$public_host" | sed 's/\./\\\\./g')
if [ "$public_port" = 443 ]; then
    public_authority=$public_host
else
    public_authority=$public_host:$public_port
fi

# Migrate environments created by older handouts without replacing their
# generated audit key or network assignments.
if ! grep -q '^PUBLIC_HOST_REGEX=' "$env_file"; then
    printf 'PUBLIC_HOST_REGEX=%s\n' "$public_host_regex" >> "$env_file"
fi
if ! grep -q '^PUBLIC_AUTHORITY=' "$env_file"; then
    printf 'PUBLIC_AUTHORITY=%s\n' "$public_authority" >> "$env_file"
fi

case "$shopnet" in
  172.28.*) ;;
  *) echo "SHOPNET must be a 172.28.x prefix" >&2; exit 1 ;;
esac

lane_hosts=
lane_zones="reviews.$host catalog.$host auditor.$host"
lane_number=0
while [ "$lane_number" -lt 64 ]; do
    lane=$(printf 'q%02x' "$lane_number")
    lane_zones="$lane_zones reviews-$lane.$host catalog-$lane.$host"
    lane_hosts="$lane_hosts
        $shopnet.30 reviews-$lane.$host catalog-$lane.$host"
    lane_number=$((lane_number + 1))
done

cat > "$runtime_dir/Corefile" <<EOF
$rebind_zone:53 {
    bind $shopnet.100
    errors
    forward . $shopnet.90:53
}

$lane_zones:53 {
    bind $shopnet.100
    errors
    hosts {
        $shopnet.30 reviews.$host catalog.$host auditor.$host
        $lane_hosts
    }
}

$host:53 {
    bind $shopnet.100
    errors
    rewrite stop name regex (.*)\\.$host_regex {1} answer auto
    forward . 127.0.0.11
}

.:53 {
    bind $shopnet.100
    errors
    forward . 1.1.1.1 8.8.8.8
}
EOF

echo "Instance configuration ready for $host on $shopnet.0/24 in $runtime_dir"
