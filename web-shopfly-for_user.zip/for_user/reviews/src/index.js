'use strict';

const crypto = require('crypto');
const path = require('path');
const express = require('express');
const nunjucks = require('nunjucks');

const app = express();
const users = new Map();
const sessions = new Map();
const reviews = [];
const socketIds = new WeakMap();
let nextSocketId = 1;
let nextReviewId = 1;
const writesLockedUntil = new Map();
const auditKey = Buffer.from(process.env.AUDIT_HMAC_KEY || '', 'utf8');
const ticketLifetime = Number(process.env.AUDIT_TICKET_TTL_SECONDS || 600);
const auditLockMs = Number(process.env.AUDIT_WRITE_LOCK_SECONDS || 180) * 1000;
const publicHost = process.env.PUBLIC_HOST || process.env.HOST || 'shopfly.test';
const publicPort = String(process.env.PUBLIC_PORT || '');
const portSuffix = publicPort && publicPort !== '443' ? `:${publicPort}` : '';
const lanePattern = /^q[0-3][0-9a-f]$/;
const maxUsersPerLane = 512;
const maxReviewsPerLane = 1024;
const maxSessions = 8192;
const sellerProfiles = new Map([
  ['softgeometry', {
    shopName: 'Soft Geometry', maker: 'Maya Chen', location: 'Portland, Oregon', joined: '2022',
    photo: '/static/images/maya-chen.webp', category: 'Ceramics & quiet rituals',
    heading: 'Useful ceramics with a softer edge.',
    story: 'Maya throws each piece in a daylight studio beside the river, then mixes satin glazes in small seasonal batches. Soft Geometry is built around objects that feel calm in the hand and earn daily use.',
    specialties: ['Wheel-thrown stoneware', 'Mineral glazes', 'Plastic-free packing'],
    rating: '4.9', dispatch: '99%', response: '< 4 hrs', orders: '1,840', accent: 'clay',
  }],
  ['northpine', {
    shopName: 'North & Pine Goods', maker: 'Elias Brooks', location: 'Asheville, North Carolina', joined: '2021',
    photo: '/static/images/elias-brooks.webp', category: 'Travel goods & repair',
    heading: 'Carry goods made for the long route.',
    story: 'Elias cuts and stitches every field bag from waxed canvas, reclaimed webbing, and repairable hardware. His workshop keeps spare panels and buckles on hand so a favorite piece can stay in service.',
    specialties: ['Waxed canvas', 'Lifetime repairs', 'Small-run hardware'],
    rating: '4.9', dispatch: '98%', response: '< 6 hrs', orders: '2,310', accent: 'forest',
  }],
  ['lumenfold', {
    shopName: 'Lumen Fold', maker: 'Inés Morales', location: 'Providence, Rhode Island', joined: '2023',
    photo: '/static/images/ines-morales.webp', category: 'Lighting & desk objects',
    heading: 'Warm light, folded into small spaces.',
    story: 'Inés prototypes lighting in paper and thin wood before translating each form into durable, repairable materials. Lumen Fold makes compact lamps and desk tools with a warm, low-glare point of view.',
    specialties: ['Low-glare lighting', 'Repairable parts', 'Paper prototyping'],
    rating: '4.8', dispatch: '97%', response: '< 1 day', orders: '986', accent: 'amber',
  }],
]);

if (auditKey.length < 32) throw new Error('AUDIT_HMAC_KEY must contain at least 32 bytes');

nunjucks.configure(path.join(__dirname, '..', 'templates'), {
  autoescape: true,
  express: app,
  noCache: true,
});

app.set('view engine', 'njk');
app.use((req, res, next) => {
  if (req.url.startsWith('/seller/') && process.env.CAPTURE_BROWSER_TRANSCRIPT === '1') {
    console.log(`CAPTURE ${JSON.stringify({ method: req.method, url: req.url, version: req.httpVersion, rawHeaders: req.rawHeaders })}`);
  }
  if (!socketIds.has(req.socket)) socketIds.set(req.socket, nextSocketId++);
  res.set('X-Upstream-Connection', `reviews-${socketIds.get(req.socket)}`);
  res.set('Content-Security-Policy', "default-src 'self'; img-src 'self' https://images.example-cdn.invalid; style-src 'self'; form-action 'self'; frame-src 'none'; object-src 'none'; base-uri 'none'");
  res.set('X-Content-Type-Options', 'nosniff');
  next();
});
app.use(express.urlencoded({ extended: false, limit: '64kb' }));
app.use('/static', express.static(path.join(__dirname, '..', 'public'), { fallthrough: false }));

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  return { salt, hash: crypto.scryptSync(password, salt, 32).toString('hex') };
}

function parseCookies(value = '') {
  return Object.fromEntries(value.split(';').map(v => v.trim().split('=')).filter(pair => pair.length === 2));
}

function requestLane(req) {
  const hostname = String(req.headers.host || '').split(':', 1)[0].toLowerCase();
  const match = hostname.match(/^(?:reviews|catalog)-(q[0-3][0-9a-f])(?:\.|$)/);
  return match ? match[1] : 'q00';
}

function accountKey(lane, username) {
  return `${lane}:${username}`;
}

function sellerExists(lane, username) {
  return users.has(accountKey(lane, username));
}

function currentUser(req) {
  const token = parseCookies(req.headers.cookie).shopfly_session;
  const session = token ? sessions.get(token) : undefined;
  return session && session.lane === requestLane(req) ? session.username : undefined;
}

function requireUser(req, res, next) {
  const username = currentUser(req);
  if (!username) return res.redirect(303, '/login');
  req.username = username;
  next();
}

function render(req, res, template, data = {}) {
  const lane = requestLane(req);
  res.render(template, {
    ...data,
    catalogUrl: `https://catalog-${lane}.${publicHost}${portSuffix}`,
    lane,
    currentUser: data.currentUser || null,
  });
}

function profileFor(username) {
  return sellerProfiles.get(username) || {
    shopName: username,
    maker: username,
    location: 'United States',
    joined: '2026',
    photo: '',
    category: 'Independent storefront',
    heading: 'Small-batch goods, carefully dispatched.',
    story: 'This independent seller participates in Shopfly’s monitored fulfillment program. Review status reflects the latest automated audit.',
    specialties: ['Verified identity', 'Tracked delivery', 'Buyer protection'],
    rating: 'New',
    dispatch: 'Monitored',
    response: '< 1 day',
    orders: 'New',
    accent: 'default',
  };
}

function reviewView(review) {
  return {
    ...review,
    stars: '★'.repeat(review.rating) + '☆'.repeat(5 - review.rating),
    profile: profileFor(review.username),
  };
}

function issueAuditTicket(lane, seller) {
  const payload = Buffer.from(JSON.stringify({
    v: 1,
    lane,
    seller,
    nonce: crypto.randomBytes(12).toString('hex'),
    exp: Math.floor(Date.now() / 1000) + ticketLifetime,
  })).toString('base64url');
  const signature = crypto.createHmac('sha256', auditKey).update(payload).digest('base64url');
  return `${payload}.${signature}`;
}

function verifyAuditTicket(ticket) {
  if (!/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(ticket || '')) return null;
  const [payload, signature] = ticket.split('.');
  const expected = crypto.createHmac('sha256', auditKey).update(payload).digest();
  let supplied;
  try { supplied = Buffer.from(signature, 'base64url'); } catch { return null; }
  if (supplied.length !== expected.length || !crypto.timingSafeEqual(supplied, expected)) return null;
  try {
    const claims = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    const now = Math.floor(Date.now() / 1000);
    if (claims.v !== 1 || !lanePattern.test(claims.lane || '') ||
        !/^[A-Za-z0-9_{}-]{3,100}$/.test(claims.seller || '') ||
        !/^[0-9a-f]{24}$/.test(claims.nonce || '') || !Number.isInteger(claims.exp) ||
        claims.exp < now || claims.exp > now + 900) return null;
    return claims;
  } catch { return null; }
}

function writesLocked(lane) {
  const expiry = writesLockedUntil.get(lane) || 0;
  if (Date.now() >= expiry) {
    writesLockedUntil.delete(lane);
    return false;
  }
  return true;
}

for (let laneNumber = 0; laneNumber < 64; laneNumber += 1) {
  const lane = `q${laneNumber.toString(16).padStart(2, '0')}`;
  for (const username of ['shopfly', ...sellerProfiles.keys()]) {
    users.set(accountKey(lane, username), { username, ...hashPassword(crypto.randomBytes(20).toString('hex')) });
  }
}
reviews.push(
  { id: nextReviewId++, lane: '*', username: 'softgeometry', rating: 5, content: 'The Orbit mug has a beautifully balanced handle and the glaze is even better in person.', status: 'Fulfilled' },
  { id: nextReviewId++, lane: '*', username: 'softgeometry', rating: 5, content: 'Maya answered my care question the same afternoon. Thoughtful packing, zero plastic.', status: 'Fulfilled' },
  { id: nextReviewId++, lane: '*', username: 'northpine', rating: 5, content: 'The field pack handled a rainy train weekend without a mark. Every pocket feels intentional.', status: 'Fulfilled' },
  { id: nextReviewId++, lane: '*', username: 'northpine', rating: 4, content: 'My bottle arrived a day early and the quiet loop is a surprisingly good detail.', status: 'Fulfilled' },
  { id: nextReviewId++, lane: '*', username: 'lumenfold', rating: 5, content: 'Warm light without desk glare. Inés included a clear repair guide and a spare diffuser clip.', status: 'Fulfilled' },
  { id: nextReviewId++, lane: '*', username: 'lumenfold', rating: 5, content: 'The Arc stand is compact, sturdy, and much nicer than the plastic one it replaced.', status: 'Fulfilled' },
  { id: nextReviewId++, lane: '*', username: 'shopfly', rating: 5, content: 'Fast delivery and careful packaging.', status: 'Fulfilled' },
);

app.get('/healthz', (_req, res) => res.status(204).end());
app.get('/', (req, res) => {
  const lane = requestLane(req);
  const laneReviews = reviews.filter(review => review.lane === '*' || review.lane === lane);
  const reviewedSellers = [...new Set(laneReviews.map(review => review.username))].reverse();
  render(req, res, 'index.njk', {
    reviews: [...laneReviews].reverse().map(reviewView),
    sellers: reviewedSellers.map(username => ({ username, ...profileFor(username) })),
    featuredSellers: ['softgeometry', 'northpine', 'lumenfold'].map(username => ({ username, ...profileFor(username) })),
    currentUser: currentUser(req),
  });
});

app.get('/about', (req, res) => render(req, res, 'about.njk', { currentUser: currentUser(req) }));
app.get('/track', (req, res) => {
  const order = String(req.query.order || '').trim().toUpperCase();
  const valid = /^[A-Z0-9-]{6,24}$/.test(order);
  render(req, res, 'track.njk', {
    order,
    searched: order.length > 0,
    tracking: valid ? {
      id: order,
      seller: 'North & Pine Goods',
      eta: 'Tomorrow, 2–6 PM',
      status: 'In transit',
    } : null,
    currentUser: currentUser(req),
  });
});

app.get('/register', (req, res) => render(req, res, 'register.njk', { username: '', error: '', currentUser: currentUser(req) }));
app.post('/register', (req, res) => {
  const lane = requestLane(req);
  const username = String(req.body.username || '');
  const password = String(req.body.password || '');
  if (!/^[A-Za-z0-9_{}-]{3,100}$/.test(username) || password.length < 8 || password.length > 128) {
    return res.status(400).render('register.njk', {
      username,
      error: 'Use a 3–100 character seller name and a password of at least 8 characters.',
      currentUser: currentUser(req) || null,
    });
  }
  if (writesLocked(lane)) return res.status(423).type('text/plain').send('Seller enrollment is paused during an active audit');
  if (sellerExists(lane, username)) {
    return res.status(409).render('register.njk', { username, error: 'That seller name is already registered.', currentUser: null });
  }
  const laneUserCount = [...users.keys()].filter(key => key.startsWith(`${lane}:`)).length;
  if (laneUserCount >= maxUsersPerLane) return res.status(503).type('text/plain').send('This marketplace lane is full');
  users.set(accountKey(lane, username), { username, ...hashPassword(password) });
  res.redirect(303, '/login');
});

app.get('/login', (req, res) => render(req, res, 'login.njk', { username: '', error: '', currentUser: currentUser(req) }));
app.post('/login', (req, res) => {
  const lane = requestLane(req);
  const username = String(req.body.username || '');
  const password = String(req.body.password || '');
  const user = users.get(accountKey(lane, username));
  const supplied = user ? hashPassword(password, user.salt).hash : ''.padEnd(64, '0');
  if (!user || !crypto.timingSafeEqual(Buffer.from(supplied, 'hex'), Buffer.from(user.hash, 'hex'))) {
    return res.status(401).render('login.njk', { username, error: 'Invalid seller credentials.', currentUser: null });
  }
  const token = crypto.randomBytes(24).toString('hex');
  if (sessions.size >= maxSessions) sessions.delete(sessions.keys().next().value);
  sessions.set(token, { lane, username });
  res.set('Set-Cookie', `shopfly_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax`);
  res.redirect(303, `/seller/${encodeURIComponent(username)}`);
});

app.get('/logout', (req, res) => {
  const token = parseCookies(req.headers.cookie).shopfly_session;
  if (token) sessions.delete(token);
  res.set('Set-Cookie', 'shopfly_session=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax');
  res.redirect(303, '/');
});

app.post('/review', requireUser, (req, res) => {
  const lane = requestLane(req);
  const content = String(req.body.content || '');
  const rating = Number(req.body.rating || 5);
  if (!content || Buffer.byteLength(content) > 8192 || !Number.isInteger(rating) || rating < 1 || rating > 5) {
    return res.status(400).type('text/plain').send('Invalid review');
  }
  if (writesLocked(lane)) return res.status(423).type('text/plain').send('Seller updates are paused during an active audit');
  if (reviews.filter(review => review.lane === lane).length >= maxReviewsPerLane) {
    return res.status(503).type('text/plain').send('This marketplace lane is full');
  }
  reviews.push({ id: nextReviewId++, lane, username: req.username, rating, content, status: 'Awaiting audit' });
  res.redirect(303, `/seller/${encodeURIComponent(req.username)}`);
});

app.post('/delete-review', requireUser, (req, res) => {
  const lane = requestLane(req);
  if (writesLocked(lane)) return res.status(423).type('text/plain').send('Seller updates are paused during an active audit');
  const id = Number(req.body.id);
  const index = reviews.findIndex(review => review.id === id && review.lane === lane && review.username === req.username);
  if (index >= 0) reviews.splice(index, 1);
  res.redirect(303, `/seller/${encodeURIComponent(req.username)}`);
});

app.get('/internal/audit-ticket/:seller', (req, res) => {
  const lane = requestLane(req);
  const seller = String(req.params.seller || '');
  const waiting = reviews.some(review => review.lane === lane && review.username === seller && review.status === 'Awaiting audit');
  if (!sellerExists(lane, seller) || !waiting) return res.status(404).type('text/plain').send('No pending seller audit');
  res.set('Cache-Control', 'no-store');
  res.type('text/plain').send(`shopfly-ticket=${issueAuditTicket(lane, seller)}`);
});

app.post('/internal/audit-lock/:ticket', (req, res) => {
  const claims = verifyAuditTicket(String(req.params.ticket || ''));
  if (!claims) return res.status(403).type('text/plain').send('Invalid audit ticket');
  const expiry = Math.min(claims.exp * 1000, Date.now() + auditLockMs);
  writesLockedUntil.set(claims.lane, Math.max(writesLockedUntil.get(claims.lane) || 0, expiry));
  res.status(204).end();
});

app.get('/seller/:username', (req, res) => {
  const lane = requestLane(req);
  const username = req.params.username;
  if (!sellerExists(lane, username)) return res.status(404).type('text/plain').send('Seller not found');
  render(req, res, 'seller.njk', {
    seller: username,
    profile: profileFor(username),
    reviews: reviews.filter(review => (review.lane === '*' || review.lane === lane) && review.username === username).reverse().map(reviewView),
    currentUser: currentUser(req),
  });
});

app.use((_req, res) => res.status(404).type('text/plain').send('Not found'));

const server = app.listen(80, '0.0.0.0', () => console.log('reviews listening on 80'));
if (process.env.CAPTURE_BROWSER_TRANSCRIPT === '1') {
  let rawConnection = 0;
  server.on('connection', socket => {
    const id = ++rawConnection;
    socket.on('data', chunk => console.log(`RAW connection=${id} hex=${chunk.toString('hex')}`));
  });
}
