'use strict';

const crypto = require('crypto');
const fs = require('fs');
const https = require('https');
const auditKey = Buffer.from(process.env.AUDIT_HMAC_KEY || '', 'utf8');
const lanePattern = /^q[0-3][0-9a-f]$/;

if (auditKey.length < 32) throw new Error('AUDIT_HMAC_KEY must contain at least 32 bytes');

const options = {
  key: fs.readFileSync('/run/shopfly/warehouse.key'),
  cert: fs.readFileSync('/run/shopfly/warehouse.crt'),
};

function parseCookies(value = '') {
  return Object.fromEntries(value.split(';').map(part => part.trim().split('=')).filter(pair => pair.length === 2));
}

function verifyTicket(ticket) {
  if (!/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(ticket || '')) return null;
  const [payload, signature] = ticket.split('.');
  const expected = crypto.createHmac('sha256', auditKey).update(payload).digest();
  let supplied;
  try { supplied = Buffer.from(signature, 'base64url'); } catch { return null; }
  if (supplied.length !== expected.length || !crypto.timingSafeEqual(supplied, expected)) return null;
  try {
    const claims = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    const now = Math.floor(Date.now() / 1000);
    if (claims.v !== 1 || !lanePattern.test(claims.lane || '') ||
        !/^[A-Za-z0-9_{}-]{3,100}$/.test(claims.seller || '') ||
        !/^[0-9a-f]{24}$/.test(claims.nonce || '') || !Number.isInteger(claims.exp) ||
        claims.exp < now || claims.exp > now + 900) return null;
    return claims;
  } catch { return null; }
}

function validOriginProof(req, ticket) {
  const supplied = parseCookies(req.headers.cookie).shopfly_audit || '';
  const expected = crypto.createHmac('sha256', auditKey).update(`origin-proof:${ticket}`).digest();
  let decoded;
  try { decoded = Buffer.from(supplied, 'base64url'); } catch { return false; }
  return decoded.length === expected.length && crypto.timingSafeEqual(decoded, expected);
}

https.createServer(options, (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'GET' && req.url === '/healthz') {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    return res.end('ok');
  }
  if (req.method === 'GET' && req.url.startsWith('/warehouse-manifest/')) {
    const ticket = req.url.slice('/warehouse-manifest/'.length).split(/[?#]/, 1)[0];
    if (!verifyTicket(ticket) || !validOriginProof(req, ticket)) {
      res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Valid audit ticket and origin proof required');
    }
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end(process.env.FLAG || '');
  }
  if (req.method === 'GET' && req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('Shopfly warehouse control plane: operational');
  }
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Not found');
}).listen(443, '0.0.0.0', () => console.log('warehouse HTTPS listening on 443'));
